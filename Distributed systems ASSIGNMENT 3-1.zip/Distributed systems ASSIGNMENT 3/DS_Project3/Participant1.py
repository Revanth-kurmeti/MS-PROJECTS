import socket
import threading
import time
import pickle

server_name = socket.gethostbyname(socket.gethostname())
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((server_name, 8686))

global client_number
client_number = 0
global voteMsg
global transactionMsg, prevMsg, prevVote
transactionMsg= "Transaction message"



def sendVote(msg):
    if msg == "CoOrdFailure":
        msg = "abort"
        
        print("Coordinator is not recieving message. Waiting for coordinator to come online")
        time.sleep(10)
        print("Coordinator came online after commit. Sending abort")
    if msg == "CoOrdFailure before commit":
        msg = "abort"
        print("Client sending vote: commit")
        print("Coordinator is not recieving message. Waiting for coordinator to come online")
        time.sleep(10)
        print("Coordinator came online after commit. Sending abort")
    prevMsg = "vote"
    prevVote = msg
    time.sleep(2)
    vote = [client_number, msg]
    data = pickle.dumps(vote)
    client.send(data)
    print("Client sent vote: {}".format(msg))


def sendAck():
    prevMsg = "vote"
    time.sleep(2)
    vote = [client_number, "yes"]
    data = pickle.dumps(vote)
    # write transaction information to file
    with open("C:/Users/revan/Downloads/DS_Project3_updated/DS_Project3/node2info.txt", "a") as f:
        # write IP address, timestamp, and acknowledgement
        f.write("Client IP: {}\n".format(socket.gethostbyname(socket.gethostname())))
        f.write("Timestamp: {}\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))
        f.write("Acknowledgement: yes\n")
    client.send(data)


def receive():
    global vote
    while True:
        data = client.recv(2048)
        data = pickle.loads(data)
        if data == "prepare":
            print("Server has requested for Vote")
            sendVote("commit")
        if data == "CoOrdFailure":
            prevMsg = data
            print("Server has requested for Vote")
            sendVote("CoOrdFailure")
        if data == "CoOrdFailure before commit":
            prevMsg = data
            print("Server has requested for Vote")
            sendVote("CoOrdFailure before commit")
        if data == "NodeFailure":
            sendVote("abort")
        if data == "NodeFailure transaction information":
            sendVote("abort")
        if data == "prepareAbort":
            print("Server has requested for Vote")
            sendVote("abort")
        if data == "commit":
            print("Commit Opeartion")
            sendAck()
        if data == "abort":
            print("Abort opeartion")
            sendAck()


def sendAndReceieveData():
    # # Thread1
    # send_message = threading.Thread(target=send)
    # send_message.start()
    # Thread2
    receive_message = threading.Thread(target=receive)
    receive_message.start()


if __name__ == '__main__':
    sendAndReceieveData()