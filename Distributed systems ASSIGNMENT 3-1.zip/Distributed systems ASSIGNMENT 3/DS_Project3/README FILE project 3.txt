README FILE:

Run the distributed_transaction_system.py file

The coordinator server will start listening for incoming client connections.
Once both clients are connected, the coordinator will prompt the user to choose a scenario to simulate.

Choose a scenario and the coordinator will broadcast a request to the clients to prepare to commit or abort a transaction.
The clients will respond with their votes and the coordinator will evaluate them.

If both clients vote to commit, the coordinator will broadcast a commit message to the clients.

If either client votes to abort, the coordinator will broadcast an abort message to the clients.

Repeat steps 4-7 for additional scenarios.

Code Structure

The makeClientConnection function listens for incoming client connections and adds them to the list of connected clients.

The simulateScenario function prompts the user to choose a scenario to simulate and broadcasts the appropriate message to the clients.

The setClientSendConnection function sends a message to all connected clients.

The clientSend function sends a message to a single client.

The clientListen function listens for a response from a single client and saves their vote or acknowledgement.

The setupClientRecConnection function sets up listening threads for all connected clients.

The evalVote function evaluates the votes from the clients and either commits or aborts the transaction.

The broadCastCommit function broadcasts a commit message to all connected clients.

The broadCastAbort function broadcasts an abort message to all connected clients.

The saveCommit function saves the vote from a single client.

The saveAck function saves the acknowledgement from a single client.






