import threading
import socket
import pickle
import time

server_name = socket.gethostbyname(socket.gethostname())

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((server_name, 8686))
client_numbers=[0,1]

global clientData, accept_commit, client_details, action
action = "prepare"
vector_clock = [0, 0, 0]
clientData = []
accept_commit = [True, True]
client_details = []
accept_ack = [True, True]


def saveCommit(msg, c_num):
    if msg == 'commit':
        msg = True
    else:
        msg = False
    accept_commit[c_num] = msg

def saveAck(msg, c_num):
    if msg == 'yes':
        msg = True
    else:
        msg = False
    accept_commit[c_num] = msg
    print("Acknoledge status {}".format(accept_ack))
    return simulateScenario()

import datetime

def evalVote():
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") # Get current timestamp
    for i, vote in enumerate(accept_commit):
        if vote == False:
            broadCastAbort(client_numbers[i])
            return
    for i, vote in enumerate(accept_commit):
        broadCastCommit(client_numbers[i])
        if action == "commit":
            with open("C:/Users/akhil/OneDrive/Desktop/DS_Project3/transactions.txt", "a") as f:
                f.write("{} Transaction committed by client at IP address {}: {}\n".format(timestamp, client_numbers[i], clientData))





def broadCastCommit(client_num):
    global action
    action = "commit"
    print("Sending commit message to client {}".format(client_num))

    return setClientSendConnection(action)


def broadCastAbort(client_num):
    global action
    action = "abort"
    print("Sending abort message to client {}".format(client_num))
    abort_sent = False  # Flag variable to track whether the abort message has been sent
    for client in client_details:
        current_thread = threading.Thread(target=clientSend, args=(client[0], client[1], action))
        current_thread.start()
    setupClientRecConnection()
    if not abort_sent:  # Check if the abort message has been sent
        abort_sent = True
    else:
        return


def broadCatReqVote():
    global action
    action = "prepare"
    return setClientSendConnection(action)

def setClientSendConnection(message):
    for client in client_details:
        current_thread = threading.Thread(target=clientSend, args=(client[0], client[1], message))
        current_thread.start()
    setupClientRecConnection()

def clientSend(connector, client_number, message):
    global action
    action = message
    if action == "CoOrdFailure":
        send_data = pickle.dumps(action)
        print("Broadcasting prepare operation to client {}".format(client_number))
        action = "prepare"
    elif action == "NodeFailure":
        send_data = pickle.dumps(action)
        print("Broadcasting prepare operation to client {}".format(client_number))
    
    elif action == "NodeFailure transaction information":
        send_data = pickle.dumps(action)
        print("Broadcasting prepare operation to client {}".format(client_number))

    elif action == "CoOrdFailure before commit":
        send_data = pickle.dumps(action)
        print("Broadcasting prepare operation to client {}".format(client_number))
        action = "prepare"

    else:
        send_data = pickle.dumps(action)
        print("Broadcasting {} operation to client {}".format(message, client_number))
    connector.send(send_data)

def clientListenNF(connector, address):
    connector.settimeout(7.0)
    clientVote = connector.recv(2048)
    if clientVote == None:
        print("Node has failed to send data")
        setClientSendConnection("abort")


def clientListen(connector, address):
    while True:
        clientVote = connector.recv(2048)
        clientData = pickle.loads(clientVote)
        client_number = clientData[0]
        if action == "prepare":
            print("Client {} has sent vote : {}".format(client_number, clientData[1]))
            saveCommit(clientData[1], client_number)
            time.sleep(3)
            evalVote()
        else:
            print("Client {} has sent ack : {}".format(client_number, clientData[1]))
            saveAck(clientData[1], client_number)
            simulateScenario()


def setupClientRecConnection():
    if action == "NodeFailure":
        time.sleep(7)
        print("\nNode failure, client not sent response. Heading for abort operation\n")
        return setClientSendConnection("abort")
    if action=="NodeFailure transaction information":
        time.sleep(7)
        print("\nNode failure, client not sent response. Heading for abort operation\n")
        return setClientSendConnection("abort")

    for client in client_details:
        current_thread = threading.Thread(target=clientListen, args=(client[0], client[1]))
        current_thread.start()


def makeClientConnection():
    while True:
        client_server_connector, addr = server.accept()
        client_address = "{}:{}".format(str(addr[0]), str(addr[1]))
        print("{} connected".format(client_address))
        client_connection = []
        client_connection.append(client_server_connector)
        client_connection.append(client_address)
        client_details.append(client_connection)
        if len(client_details) > 1:
            simulateScenario()

def simulateScenario():
    broadcasted = False
    while not broadcasted:
        res = input("Type: "
                    "\n 1. BothCommit "
                    "\n2. BothAbort"
                    "\n3. CoOrdFailure"
                    "\n4. NodeFailure"
                    "\n5.CoOrdFailure after commit"
                    "\n6.NodeFailure transaction information\n\n")
        if res == "1":
            setClientSendConnection("prepare")
            broadCastCommit(client_numbers)
            broadcasted = True
        if res == "2":
            setClientSendConnection("prepareAbort")
            broadCastAbort(client_numbers)
            broadcasted = True
        if res == "3":
            setClientSendConnection("CoOrdFailure")
            broadCastAbort(client_numbers)
            broadcasted = True
        if res == "4":
            setClientSendConnection("NodeFailure")
            broadcasted = True
        if res == "5":
            setClientSendConnection("CoOrdFailure before commit")
            broadCastAbort(client_numbers)
            broadcasted = True
        if res=="6":
            setClientSendConnection("NodeFailure transaction information")
            broadcasted = True




if __name__ == '__main__':
    server.listen(5)
    print("Coordinator server started\n")
    master_thread = threading.Thread(target=makeClientConnection, args=())
    master_thread.start()
