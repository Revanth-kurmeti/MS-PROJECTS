import asyncio
import json

class ComputationServer:
    def __init__(self):
        self.results = {}

    def add(self, i, j):
        return i + j

    def sort(self, array):
        return sorted(array)

    async def handle_rpc_call(self, request_json, respond):
        request = json.loads(request_json)
        method = request['method']
        params = request['params']
        id = request['id']
        result = None
        error = None
        if method == 'add':
            result = self.add(*params)
        elif method == 'sort':
            result = self.sort(*params)
        else:
            error = f'Method {method} not supported'
        response = {'id': id, 'result': result, 'error': error}
        respond(json.dumps(response).encode())

server = ComputationServer()

async def run_server():
    server = await asyncio.start_server(
        server.handle_rpc_call, '127.0.0.1', 8001)

    addr = server.sockets[0].getsockname()
    print(f'Serving on {addr}')

    async with server:
        await server.serve_forever()

async def rpc_call(method, params, id, respond=None):
    request = {'method': method, 'params': params, 'id': id}
    request_json = json.dumps(request)
    reader, writer = await asyncio.open_connection('127.0.0.1', 8001)
    writer.write(request_json.encode())
    await writer.drain()
    if respond is None:
        # synchronous call
        response_json = await reader.readline()
        response = json.loads(response_json.decode())
        return response['result']
    else:
        # asynchronous call
        respond({'status': 'accepted'})
        writer.close()
        await writer.wait_closed()

async def synchronous_call():
    result = await rpc_call('add', (1, 2), 0)
    print(f'Result: {result}')

async def asynchronous_call(respond):
    await rpc_call('sort', ([3, 2, 1],), 1, respond)

async def main():
    await asyncio.gather(
        run_server(),
        synchronous_call(),
        asynchronous_call(print),
    )

asyncio.run(main())
