import xmlrpc.server
from typing import List

class ComputationServer:
    def __init__(self):
        self.add_result = 0
        self.sort_result = []

    def add(self, i: int, j: int):
        self.add_result = i + j
        return self.add_result

    def sort(self, A: List[int]):
        self.sort_result = sorted(A)
        return self.sort_result

if __name__ == "__main__":
    server = xmlrpc.server.SimpleXMLRPCServer(("localhost", 3000))
    server.register_instance(ComputationServer())
    server.serve_forever()
