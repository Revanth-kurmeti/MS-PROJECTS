import xmlrpc.client

file_server = xmlrpc.client.ServerProxy("http://localhost:8000/")
computation_server = xmlrpc.client.ServerProxy("http://localhost:8001/")
with open("file.txt", "w+") as f:
    f.write("My name is ----")
# Upload a file
with open("file.txt", "rb") as f:
    file_data = xmlrpc.client.Binary(f.read())
    file_server.upload("file.txt", file_data)
    print("file uploaded successfully")

# # Download a file
file_data = file_server.download("file.txt")
with open("./clientData/file_downloaded.txt", "wb") as f:
    f.write(file_data.data)
    print("file downloaded successfully")

# # Delete a file
file_server.delete("file.txt")
print("file deleted successffully")

# # Rename a file
file_server.rename("file_downloaded.txt", "renamed_file.txt")
print("file renamed successfully")


