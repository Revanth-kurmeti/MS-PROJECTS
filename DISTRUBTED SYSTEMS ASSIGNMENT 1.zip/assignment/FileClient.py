import threading
import xmlrpc.client
import time
import os

class FileClient:
    def __init__(self, folder):
        self.server = xmlrpc.client.ServerProxy('http://localhost:8000/RPC2')
        self.folder = folder
        self.update_thread = threading.Thread(target=self.check_updates)
        self.update_thread.start()
        self.last_modified_time = {}

    def upload(self, file_name, file_path):
        
        with open(file_path, 'rb') as f:
            file_data = xmlrpc.client.Binary(f.read())
        return self.server.upload(file_name, file_data)
    print("file uploaded successfully")
    
    def download(self, file_name, file_path):
        success, file_data = self.server.download_file(file_name)
        if not success:
            return False
        with open(file_path, 'wb') as f:
            f.write(file_data.data)
        return True
    print("file uploaded successfully")    
    
    def delete(self, file_name):
        return self.server.delete(file_name)
    print("file deleted successfully")

    def rename(self, old_name, new_name):
        return self.server.rename(old_name, new_name)
    print("file uploaded successfully")
    
    def check_updates(self):
        while True:
            for file in os.listdir(self.folder):
                file_path = os.path.join(self.folder, file)
                last_modified_time = os.path.getmtime(file_path)
                self.upload(file, file_path)
                self.last_modified_time[file] = last_modified_time
            time.sleep(5)

def main():
    folder = './client_update'
    client = FileClient(folder)

if __name__ == '__main__':
    main()
