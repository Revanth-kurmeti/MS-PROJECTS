from typing import List
import xmlrpc.client

class Client:
    def __init__(self):
        self.proxy = xmlrpc.client.ServerProxy("http://localhost:3000/")

    def synchronous_add(self, i: int, j: int):
        return self.proxy.add(i, j)

    def asynchronous_add(self, i: int, j: int):
        self.proxy.add(i, j)
        print("Asynchronous add called, result can be fetched later")

    def fetch_add_result(self):
        return self.proxy.add_result

    def synchronous_sort(self, A: List[int]):
        return self.proxy.sort(A)

    def asynchronous_sort(self, A: List[int]):
        self.proxy.sort(A)
        print("Asynchronous sort called, result can be fetched later")

    def fetch_sort_result(self):
        return self.proxy.sort_result

if __name__ == "__main__":
    client = Client()
    print(client.synchronous_add(5, 6))
    client.asynchronous_add(3, 4)
    print(client.fetch_add_result())
    print(client.synchronous_sort([5, 4, 3, 2, 1]))
    client.asynchronous_sort([5, 4, 3, 2, 1])
    print(client.fetch_sort_result())
