import time
import xmlrpc.server
from typing import List

class ComputationServer:
    def add(self, i, j):
        return i + j

    def sort(self, A: List[int]):
        A.sort()
        return A

class SynchronousServer:
    def add(self, i, j):
        server = xmlrpc.server.SimpleXMLRPCServer(("localhost", 3000))
        server.register_instance(ComputationServer())
        print("Listening on port 3000...")
        server.serve_forever()

class AsynchronousServer:
    def add(self, i, j):
        server = xmlrpc.server.ThreadingXMLRPCServer(("localhost", 3000))
        server.register_instance(ComputationServer())
        print("Listening on port 3000...")
        server.serve_forever()

if __name__ == "__main__":
    mode = input("Enter the mode of server (Synchronous/Asynchronous): ")
    if mode == "Synchronous":
        server = SynchronousServer()
    elif mode == "Asynchronous":
        server = AsynchronousServer()
    else:
        print("Invalid mode")
