import xmlrpc.server
from xmlrpc.server import SimpleXMLRPCServer
import os

class FileServer:
    def upload(self, file_name, file_data):
        # Save the file to disk
        print("reached")
        print(file_name)
        print(file_data)
        # with open("./serverData/"+file_name, "wb") as f:
        #f.write(file_data.data)
        f = open("./serverData/"+file_name, "a")
        f.write("Now the file has more content!")
        f.close()
        return True

    def download(self, file_name):
        # Check if the file exists
        if not os.path.exists(file_name):
            return False
        with open("./serverData/"+file_name, "rb") as f:
            file_data = f.read()
        return xmlrpc.client.Binary(file_data)

    def delete(self, file_name):
        # Check if the file exists
        if not os.path.exists("./serverData/"+file_name):
            return False
        os.remove("./serverData/"+file_name)
        return True

    def rename(self, old_file_name, new_file_name):
        # Check if the old file exists
        if not os.path.exists("./clientData/"+old_file_name):
            return False
        os.rename("./clientData/"+old_file_name, "./clientData/"+new_file_name)
        return True

if __name__ == "__main__":
    file_server = SimpleXMLRPCServer(("0.0.0.0", 8000))
    file_server.register_instance(FileServer())
    file_server.serve_forever()
