import threading
import socket
import pickle

class VectorClock:
    def __init__(self, process_id, num_processes):
        self.vector = [0] * num_processes
        self.vector[process_id] = 0  # set this process's clock value to 0
        self.process_id = process_id

    def increment(self):
        self.vector[self.process_id] += 1

    def merge(self, other):
        for i in range(len(self.vector)):
            self.vector[i] = max(self.vector[i], other.vector[i])

    def __str__(self):
        return str(self.vector)

class Process:
    def __init__(self, process_id, num_processes, port):
        self.process_id = process_id
        self.num_processes = num_processes
        self.port = port
        self.vector_clock = VectorClock(process_id, num_processes)
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.bind(('localhost', port))
        self.server_socket.listen()

    def send(self, message):
        print(f"Process {self.process_id} Vector Clock before broadcasting message: {self.vector_clock}")
        self.vector_clock.increment()
        print(f"Process {self.process_id} Vector Clock after broadcasting message: {self.vector_clock}")
        for i in range(self.num_processes):
            if i != self.process_id:
                client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                client_socket.connect(('localhost', processes[i].port))
                client_socket.send(pickle.dumps((self.vector_clock, message)))
                client_socket.close()

    def receive(self, client_socket):
        while True:
            data = client_socket.recv(4096)
            if not data:
                return
            other_vector_clock, message = pickle.loads(data)
            self.vector_clock.increment()
            print(f"Process {self.process_id} Vector Clock before receiving message from {other_vector_clock.process_id}: {self.vector_clock}")
            self.vector_clock.merge(other_vector_clock)
            print(f"Process {self.process_id} Vector Clock after receiving message from {other_vector_clock.process_id}: {self.vector_clock}, Message: {message}")

    def listen(self):
        while True:
            client_socket, addr = self.server_socket.accept()
            threading.Thread(target=self.receive, args=(client_socket,)).start()

# Initialize processes
num_processes = 3
processes = {}
for i in range(num_processes):
    port = 8000 + i
    processes[i] = Process(i, num_processes, port)

# Print initial vectors for all processes
for i in range(num_processes):
    print(f"Process {i} initial vector clock: {processes[i].vector_clock}")

# Start listening threads for all processes
for i in range(num_processes):
    threading.Thread(target=processes[i].listen).start()

# Continuous input loop for sending messages
while True:
    try:
        sender_id = int(input("Enter sender ID: "))
        if sender_id not in processes:
            raise ValueError
        message = input("Enter message: ")
        processes[sender_id].send(message)
        choice = input("Do you want to send more messages? (y/n): \n")
        if choice.lower() == 'n':
            break
    except ValueError:
        print("Invalid ID. Please enter a valid ID")
